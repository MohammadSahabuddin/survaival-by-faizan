/** @jsxImportSource theme-ui */
import Image from "next/image";
import { Box, Container, Flex, Heading, Paragraph, Text } from "@theme-ui/components"

import Icons from "utils/Icons";


function Challenges({ challenge }) {
    return (
        <Container sx={styles.container}>
            <Flex className="flex">
                <Box className="left" sx={styles.left}>
                    <Heading as="h2" sx={styles.heading}>{challenge.heading}</Heading>
                    <Box className="map">
                        {challenge.blocks &&
                            challenge.blocks.map((block, i) => (
                                <Flex className="flex2" key={i} sx={styles.cards}>
                                    <Box className="leftImage" sx={styles.leftImage}><Image src={block.image1} width={400} height={243} /></Box>
                                    <Box className="leftTextGroup" sx={styles.leftTextGroup}>
                                        <Heading as="h5" sx={styles.skills}>{block.text1st}</Heading>
                                        <Heading as="h3" sx={styles.groupHeader}>{block.heading2} </Heading>
                                        <Paragraph as="p" >{block.text2nd} </Paragraph>
                                        <Flex className="flex3" sx={{ cursor: "pointer" }}>
                                            <Box className="firstIcon" sx={styles.firstIcon}><Icons icon={block.icon} /></Box>
                                            <Box><Heading as="h5">{block.iconText} </Heading></Box>
                                        </Flex>
                                    </Box>
                                </Flex>
                            ))}
                    </Box>
                </Box>
                <Box className="right" sx={styles.right}>
                    <Box className="topTextGroup">
                        <Flex className="rightFlex" sx={styles.rightHeading}>
                            <Text>{challenge.num}</Text>
                            <Heading as="h1">
                                {challenge.backTextFIrst}<br />
                                {challenge.backTextMiddle}<br />
                                {challenge.backTextLast}
                            </Heading>
                        </Flex>
                        <Box className="rotate" sx={styles.rotate}><Heading as="h2">{challenge.rotatedText} </Heading> </Box>
                        <Box className="image2">
                            <Image src={challenge.image2} width={643} height={528} />
                        </Box>
                    </Box>
                    <Box className="bottom" sx={styles.bottom}>
                        <Heading as="h3">{challenge.heading3} </Heading>
                        <Heading as="h4">{challenge.heading4} </Heading>
                        <Paragraph as="p">{challenge.text2nd} </Paragraph>
                        <Flex className="flex4" sx={{ cursor: "pointer" }}>
                            <Box sx={styles.firstIcon}><Icons icon={challenge.icon2} /></Box>
                            <Heading as="h5">{challenge.text3rd}</Heading>
                        </Flex>
                    </Box>
                </Box>
            </Flex>
        </Container>
    )
}

export default Challenges

const styles = {
    container: {
        p: ["100px"]
    },
    left: {
        flex: ["0 0 60%"],
        flexWrap: 'wrap',
    },
    heading: {
        fontSize: ["35px"],
        marginBottom: "30px",
        fontWeight: "text"
    },
    right: {
        flex: ["0 0 46%"],
        flexWrap: 'wrap',
        ml: "50px"
    },
    cards: {
        m: "0 0 20px 0",
    },
    leftImage: {
        flex: ["0 0 52%"],
        flexWrap: 'wrap',
    },
    leftTextGroup: {
        flex: ["0 0 43%"],
        flexWrap: 'wrap',
        ml: "26px",
        mt: "30px",
        p: {
            fontSize: "11px",
            lineHeight: "18px",
            margin: "15px 0"
        },
        h5: {
            fontSize: "13px",
            fontWeight: "text",
            textTransform: "uppercase"
        },
    },
    skills: {
        color: "primary"
    },
    groupHeader: {
        fontSize: "25px",
        fontWeight: "text",
        mt: "5px"
    },
    firstIcon: {
        margin: "2px 14px 0 0",
        fontSize: "20px",

    },
    rightHeading: {
        position: "relative",
        span: {
            fontSize: ["50px"],
            color: "primary"
        },
        h1: {
            position: "absolute",
            textTransform: "uppercase",
            fontSize: "116px",
            color: "#fff",
            zIndex: -999,
            top: 0,
            left: "50px",
            fontWeight: "text",
            lineHeight: "100px",
        }
    },
    rotate: {
        position: "relative",
        h2: {
            textTransform: "lowercase",
            fontWeight: 400,
            fontSize: "60px",
            position: "absolute",
            transform: "rotate(-20deg)",
            zIndex: -99,
            top: "10px",
            left: "23%",
            color: "primary"
        }
    },
    bottom: {
        mt: "-40px",
        width: "90%",
        h3: {
            fontSize: "60px",
            mb: "28px",
            fontWeight: "body"
        },
        h4: {
            fontSize: "27px",
            width: "85%",
            fontWeight: 400,
            mb: "20px",
            lineHeight: "30px",
        },
        p: {
            fontSize: "15px",
            width: "86%",
            mb: "22px"
        },
        h5: {
            fontSize: "13px",
            fontWeight: "text",
            textTransform: "uppercase"
        },
    }
}