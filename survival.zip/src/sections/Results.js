/** @jsxImportSource theme-ui */

import { Box, Container, Flex, Heading, Paragraph, Text } from "@theme-ui/components";
import Image from "next/image";

import Icons from "utils/Icons";

function Results({ results }) {
    return (
        <Container as="section" sx={styles.container}>
            <Flex>
                <Box className="left" sx={styles.left}>
                    <Paragraph>{results.firstText}</Paragraph>
                    <Text sx={styles.left1stNum}>{results.num}</Text>
                    <Box className="heading" sx={styles.leftHeading}>
                        <Heading as="h1">{results.firstHeading}</Heading>
                        <Heading as="h1" sx={styles.middleHead}>{results.percent}</Heading>
                        <Heading as="h1" sx={styles.lastHead}>{results.lastHeading}</Heading>
                    </Box>
                    <Heading as="h2" sx={styles.rotate}>
                        {results.rotate}
                    </Heading>
                    <Flex className="flex4" sx={styles.button}>
                        <Box><Icons icon={results.icon} /></Box>
                        <Heading as="h5">{results.iconText}</Heading>
                    </Flex>
                    <Box className="img" sx={styles.leftImage}>
                        <Image src={results.img} width={226.75} height={151.17} />
                    </Box>
                </Box>
                <Box sx={styles.right}>
                    <Box sx={styles.rightImage}>
                        <Image src={results.img2} width={672} height={652} />
                    </Box>
                    <Box className="rightContent" sx={styles.rightContent}>
                        <Heading as="h1">{results.rightHead}</Heading>
                        <Heading as="h3">{results.rightText}</Heading>
                        <Flex className="flex4" sx={styles.icons}>
                            <Box><Icons icon={results.icon} /></Box>
                            <Heading as="h5">{results.iconText1}</Heading>
                        </Flex>
                    </Box>
                </Box>
            </Flex >
        </Container >
    )
}

export default Results;

const styles = {
    container: {
        p: "100px",
    },
    right: {
        flex: ["0 0 70%"],
        position: "relative",
    },
    left: {
        flex: ["0 0 40%"],
        position: "relative",
        mt: ["165px"],
        p: {
            textTransform: "uppercase",
            fontSize: "12px",
            mb: ["-25px"]
        },
        span: {
            fontFamily: "roboto"
        }
    },
    left1stNum: {
        fontSize: ["170px"],
        color: "primary",
        ml: ["60px"]
    },
    rightImage: {
        fontSize: "16px"
    },
    rightContent: {
        border: "13px solid #E4003B",
        width: "50%",
        position: "absolute",
        top: "10%",
        left: "18%",
        color: "secondary",
        p: ["15px 0 15px 83px"],
        h1: {
            fontSize: "41px",
            fontWeight: "text",
            textTransform: "uppercase",
            lineHeight: "36px",
            mt: "187px"
        },
        h3: {
            fontSize: "26px",
            fontWeight: "text",
            mt: "26px"
        },
    },
    icons: {
        cursor: "pointer",
        mt: ["43px"],
        svg: {
            fontSize: ["25px"]
        },
        h5: {
            fontSize: ["11px"],
            textTransform: "uppercase",
        }
    },
    leftImage: {
        position: "absolute",
        bottom: "8%",
        right: "-20%",
        zIndex: 9999,
        width: "30%"
    },
    leftHeading: {
        mt: "-40px",
        h1: {
            fontSize: "60px",
            lineHeight: "60px",
            fontWeight: "text"
        }
    },
    middleHead: {
        color: "primary",
        fontFamily: "roboto"
    },
    lastHead: {
        mt: ["-9px"]
    },
    rotate: {
        position: "absolute",
        top: "-18%",
        left: "-40%",
        transform: "rotate(-90deg)",
        textTransform: "uppercase",
        fontSize: "109px",
        color: "white",
        width: "241%",
        fontWeight: 400,
        zIndex: 9999,
        letterSpacing: "9px"
    },
    button: {
        mt: ["20px"],
        fontSize: "22px",
        textTransform: "uppercase",
        cursor: "pointer",
        h5: {
            fontSize: "13px",
            ml: "6px"
        }
    }
}
