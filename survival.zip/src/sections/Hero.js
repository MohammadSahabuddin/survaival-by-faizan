/** @jsxImportSource theme-ui */
import { Container, Flex, Box, Paragraph, Heading } from 'theme-ui';
import Image from 'next/image';

import Icons from 'utils/Icons';
import Img from 'assets/hero/ico.png'
import HeroSlider from 'components/HeroSlider';

function Hero({ heros }) {
    return (
        <Container as="section">
            <Flex className="1stFlex">
                <Box className="leftContents" sx={styles.leftContent} >
                    <Flex className="2ndFlex">
                        <Box className="inner">
                            <Box className="rotate" sx={styles.rotate}>
                                <Heading as="h3">{heros.rotated}</Heading>
                            </Box>
                            <Box className="icons" sx={styles.icon}>
                                <Icons icon={heros.firstIcon} />
                                <Icons icon={heros.secondIcon} />
                                <Icons icon={heros.thirdIcon} />
                            </Box>
                        </Box>
                        <Box className="main_heading" sx={styles.heading}>
                            <Box className="heading">
                                <Heading as="h1">{heros.firstHeading}</Heading><br />
                                <Heading as="h1">{heros.secondHeading}</Heading><br />
                                <Heading as="h1">{heros.thirdHeading}</Heading>
                            </Box>
                            <Box className="Paragraph" sx={styles.paragraph}>
                                <Paragraph as="p">{heros.text}</Paragraph>
                            </Box>
                            <Box className="back_image" sx={styles.back}>
                                <Image src={Img} height={226.75} width={151.17} />
                            </Box>
                        </Box>
                    </Flex>
                </Box>
                <Box className="middleContents" sx={styles.middleContent} >
                    <HeroSlider slider={heros.slides} />
                </Box>
            </Flex>
        </Container>
    )
}

export default Hero;

const styles = {
    middleContent: {
        flex: ["0 0 58%"],
        flexWrap: 'wrap',
    },
    leftContent: {
        flex: ["0 0 32%"],
        flexWrap: 'wrap',
    },
    rotate: {
        height: "100%",
        h3: {
            transform: "rotate(-90deg)",
            fontSize: "35px",
            width: "18rem",
            margin: "9.2rem 0 0 23px",
            fontWeight: "400"
        }
    },
    icon: {
        m: "-140px 0 0 129px",
        textAlign: "center",
        svg: {
            fontSize: "20px",
            m: "5px 0",
        }
    },
    heading: {
        position: "relative",
        width: "83%",
        mt: "42px",
        h1: {
            fontSize: "100px",
            color: "heading",
            lineHeight: "59px",
            fontWeight: "text"
        }
    },
    paragraph: {
        fontSize: "12px",
        mt: "10px",
        width: "83%"
    },
    back: {
        position: "absolute",
        top: "69%",
        right: "7%",
        zIndex: -99
    }
}
