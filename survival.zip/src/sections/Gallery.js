/** @jsxImportSource theme-ui */
import { Box, Container, Flex, Paragraph, Heading } from "@theme-ui/components";
import Image from "next/image";

import Icons from "utils/Icons";
import Back from "assets/gallery/icon.png"

function Gallery({ galleries }) {
    return (
        <Container as="section" sx={styles.container}>
            <Flex>
                <Box className="youtubeContainer" sx={styles.youtube}>
                    <Box>
                        <Image src={galleries.youtube.image} width={360} height={300} />
                    </Box>
                    <Box className="youtubeContent" sx={styles.youtubeContent}>
                        <Box><Icons icon={galleries.youtube.icon} /></Box>
                        <Flex sx={styles.headings}>
                            <Heading as="h6">{galleries.youtube.date}</Heading>
                            <hr sx={styles.hr} />
                            <Heading as="h6">{galleries.youtube.title}</Heading>
                        </Flex>
                        <Paragraph as="p">{galleries.youtube.description}</Paragraph>
                    </Box>
                </Box>
                <Box className="photoContainer" sx={styles.photo}>
                    <Box>
                        <Image src={galleries.photo.image} width={360} height={300} />
                    </Box>
                    <Box className="photoContent" sx={styles.photoContent}>
                        <Box><Icons icon={galleries.photo.icon} /></Box>
                        <Flex sx={styles.headings}>
                            <Heading as="h6">{galleries.photo.date}</Heading>
                            <hr sx={styles.hr} />
                            <Heading as="h6">{galleries.photo.title}</Heading>
                        </Flex>
                        <Paragraph as="p">{galleries.photo.description}</Paragraph>
                    </Box>
                </Box>
                <Box className="contents" sx={styles.info}>
                    <Heading as="h1">{galleries.info.heading}</Heading>
                    <Heading as="h2">{galleries.info.rotate}</Heading>
                    <Paragraph as="p">{galleries.info.description}</Paragraph>
                    <Flex>
                        <Icons icon={galleries.info.icon} />
                        <Heading as="h3">{galleries.info.iconText}</Heading>
                    </Flex>
                    <Box className="infoImage" sx={styles.infoImage}>
                        <Image src={Back} width={126.75} height={151.17} />
                    </Box>
                </Box>
            </Flex>
        </Container>
    )
}

export default Gallery;

const styles = {
    container: {
        p: ["50px"]
    },
    youtube: {
        flex: ["0 0 33%"],
        flexWrap: 'wrap',
        position: "relative"
    },
    youtubeContent: {
        position: "absolute",
        top: "11%",
        left: "7%",
        color: "secondary",
        width: "75%",
        svg: {
            fontSize: "22px",
            mb: ["100px"]
        },
        p: {
            fontSize: ["24px"]
        }
    },
    photo: {
        flex: ["0 0 33%"],
        flexWrap: 'wrap',
        position: "relative"
    },
    photoContent: {
        position: "absolute",
        top: "11%",
        left: "7%",
        color: "secondary",
        width: "75%",
        svg: {
            fontSize: "22px",
            mb: ["100px"]
        },
        p: {
            fontSize: ["24px"]
        }
    },
    hr: {
        m: "6px 5px 0",
        p: 0,
        color: "white",
        height: "13px",
    },
    headings: {
        mb: ["10px"],
        h6: {
            fontSize: ["14px"]
        }
    },
    info: {
        flex: ["0 0 33%"],
        flexWrap: 'wrap',
        position: "relative",
        h1: {
            fontSize: ["70px"],
            textTransform: "uppercase",
            m: ["60px 0 50px"],
            fontWeight: "text",
        },
        h2: {
            zIndex: 9999,
            position: "absolute",
            transform: "rotate(-10deg)",
            color: "primary",
            fontSize: "50px",
            top: "38%",
            left: "2%",
        },
        p: {
            fontSize: ["14px"],
            mt: ["78px"]
        },
        svg: {
            fontSize: "20px",
            mt: "16px"
        },
        h3: {
            m: "15px 0 0 13px",
            textTransform: "uppercase",
            fontWeight: "text",
            fontSize: "14px"
        }
    },
    infoImage: {
        position: "absolute",
        bottom: "-10%",
        right: "-16%"
    }
}
