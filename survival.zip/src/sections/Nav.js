/** @jsxImportSource theme-ui */
import Image from 'next/image';
import { Container, Flex, Box, NavLink, Select } from 'theme-ui';

import Icons from 'utils/Icons';

function Nav({ nav }) {
    return (
        <Container as="section" className="container" sx={styles.container}>
            <Flex className="mainFlex">
                <Box sx={styles.logo} className="logo">
                    <NavLink href={nav.logoUrl} className="logoLink">
                        <Image src={nav.img} width={223.59} height={103.96} className="logoImg" />
                    </NavLink>
                </Box>
                <Box sx={styles.rightContent} className="rightContent">
                    <Flex className="flex1st">
                        <Box className="box1st">
                            <Flex className="navLink" sx={styles.navLink}>
                                {nav.navs.map((nav, i) => (
                                    <NavLink href={nav.url} key={i} className="mapLink">
                                        {nav.name}
                                    </NavLink>
                                ))}
                            </Flex>
                        </Box>
                        <hr className="hrTag" sx={styles.hr} />
                        <Box className="box2nd">
                            <Flex className="flex2nd">
                                <Box className="selected" sx={styles.selected}>
                                    <Select
                                        sx={styles.select}
                                        arrow={
                                            <Box
                                                className="selectBox"
                                                as="svg"
                                                width="50"
                                                height="14"
                                                viewBox="0 0 24 24"
                                                fill="currentcolor"
                                                sx={{
                                                    ml: -10,
                                                    alignSelf: 'center',
                                                    pointerEvents: 'none',
                                                }}>
                                            </Box>
                                        }
                                        defaultValue="ENG">
                                        {nav.languages.map((language, i) => (
                                            <option key={i} className="option">{language.name}</option>
                                        ))}
                                    </Select>
                                </Box>
                                <Box className="firstIcon" sx={styles.firstIcon}>
                                    <Icons icon={nav.firstIcon} />
                                </Box>
                                <Box className="secondIcon" sx={styles.secondIcon}>
                                    <Icons icon={nav.secondIcon} />
                                </Box>
                            </Flex>
                        </Box>
                    </Flex>
                </Box>
            </Flex>
        </Container>
    )
}

export default Nav;

const styles = {
    container: {
        p: ["50px 50px 30px 120px"],
    },
    logo: {
        flex: ["0 0 55%"],
        flexWrap: 'wrap',
        a: {
            width: ["25%"],
            m: ["-18px 0 0 0"]
        }
    },
    rightContent: {
        flex: ["0 0 45%"],
        flexWrap: 'wrap',
    },
    navLink: {
        a: {
            mr: "15px",
            fontSize: "16px",
            fontWeight: 400,
            textTransform: "uppercase",
            fontFamily: "body"
        }
    },
    hr: {
        m: ["-4px 13px 0"],
        height: ["30px"],
        color: "#0006"
    },
    selected: {
        flex: ["0 0 50%"],
        flexWrap: 'wrap',
    },
    select: {
        transition: "left 0.7s cubic-bezier(0.545, 0, 0.05, 1)",
        bg: "transparent",
        border: "none",
        p: "0",
        m: "0",
        cursor: "pointer"
    },
    firstIcon: {
        flex: ["0 0 33%"],
        flexWrap: 'wrap',
        svg: {
            fontSize: ["19px"],
            cursor: "pointer"
        }
    },
    secondIcon: {
        flex: ["0 0 33%"],
        flexWrap: 'wrap',
        svg: {
            fontSize: ["19px"],
            fontSize: ["35px"],
            background: "secondary",
            borderRadius: "50%",
            padding: ["7px"],
            margin: ["-7px 0 0"],
            color: "secondary",
            cursor: "pointer",
        }
    }
}
