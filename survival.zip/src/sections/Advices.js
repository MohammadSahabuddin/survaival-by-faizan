/** @jsxImportSource theme-ui */
import { Container, Flex, Box, Paragraph, Heading } from 'theme-ui';

import Icons from 'utils/Icons';
import AdviceSliders from 'components/AdviceSlider';

function Advices({ advice }) {
    return (
        <Container as="section" sx={styles.container}>
            <Flex className="1stFlex">
                <Box className="leftContents" sx={styles.leftContent}>
                    <Flex className="2ndFlex">
                        <Box className="inner">
                            <Box className="rotate" sx={styles.rotate}>
                                <Heading as="h3">{advice.rotated}</Heading>
                            </Box>
                        </Box>
                        <Box className="main_heading" sx={styles.heading}>
                            <Box><Heading as="h2">{advice.heading}</Heading></Box>
                            <Box className="Paragraph" sx={styles.paragraph}>
                                <Paragraph as="p">{advice.text}</Paragraph>
                            </Box>
                            <Flex sx={styles.icons}>
                                <Icons icon={advice.icon} />
                                <Heading as="h3">{advice.iconText}</Heading>
                            </Flex>
                        </Box>
                    </Flex>
                </Box>
                <Box className="middleContents" sx={styles.middleContent} >
                    <AdviceSliders slider={advice.slides} />
                </Box>
            </Flex>
        </Container>
    )
}

export default Advices;

const styles = {
    container: {
        p: ["100px 0 100px 200px"],
        position: "relative"
    },
    middleContent: {
        flex: ["0 0 90%"],
        flexWrap: 'wrap',
    },
    leftContent: {
        flex: ["0 0 10%"],
        flexWrap: 'wrap',
        position: "absolute",
        bg: "back",
        zIndex: 999,
        width: "30%",
        p: "0",
        m: "0",
        bottom: "15.6%",
        left: "14.8%"
    },
    rotate: {
        height: "100%",
        position: "absolute",
        top: "-96%",
        left: "-73%",
        h3: {
            transform: "rotate(-90deg)",
            fontSize: "130px",
            fontWeight: "text",
            textTransform: "uppercase",
            fontFamily: "open",
            color: "primary"
        }
    },
    heading: {
        position: "relative",
        mt: "22px",
        ml: "39px",
        h2: {
            fontSize: "45px",
            textTransform: "uppercase",
            fontWeight: "text"
        }
    },
    paragraph: {
        p: {
            fontSize: "11px",
            lineHeight: "20px",
            width: "88%"
        }
    },
    icons: {
        fontSize: "20px",
        mt: "10px",
        h3: {
            fontSize: "12px",
            margin: "-2px 0 0 12px",
            textTransform: "uppercase",
            fontFamily: "open",
        }
    }
}
