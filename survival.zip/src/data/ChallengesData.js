import Img from "assets/challenges/Mask.png";
import Imgs from "assets/challenges/shoes.png";

export default {
    heading: "Popular challenges",
    num: "01",
    backTextFIrst: "endu",
    backTextMiddle: "ranc",
    backTextLast: "e",
    rotatedText: "challenges",
    image2: Imgs,
    heading3: "Mission",
    heading4: "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy tempor.",
    text2nd: "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.",
    icon2: "emojione:cross-mark",
    text3rd: "Find out more",
    blocks: [
        {
            image1: Img,
            text1st: "Key Skills",
            heading2: "Friction-Based Fire Making",
            text2nd: "Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem.",
            icon: "emojione:cross-mark",
            iconText: "Find out more",
        },
        {
            image1: Img,
            text1st: "Key Skills",
            heading2: "Friction-Based Fire Making",
            text2nd: "Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem.",
            icon: "emojione:cross-mark",
            iconText: "Find out more",
        },
        {
            image1: Img,
            text1st: "Key Skills",
            heading2: "Friction-Based Fire Making",
            text2nd: "Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem.",
            icon: "emojione:cross-mark",
            iconText: "Find out more",
        }
    ]

}