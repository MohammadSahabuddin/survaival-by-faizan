import img1 from "assets/hero/1.png";
import img2 from "assets/hero/2.png";
// import vid from "assets/videos/demo.mp4";


export default {
    rotated: "advice",
    icon: "emojione-v1:cross-mark",
    iconText: "more",
    heading: "survival mode",
    text: "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.",
    slides: [
        {
            img: img1,
        },
        {
            img: img2,
        }
    ]
}