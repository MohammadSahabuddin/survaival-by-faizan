import img0 from "assets/hero/0.png";
import img1 from "assets/hero/1.png";
import img2 from "assets/hero/2.png";
// import vid from "assets/videos/demo.mp4";


export default {
    rotated: "Find out if you can",
    firstIcon: "brandico:facebook",
    secondIcon: "akar-icons:twitter-fill",
    thirdIcon: "ls:youtube",
    firstHeading: "SU",
    secondHeading: "RVI",
    thirdHeading: "VE",
    text: "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labor.",
    slides: [
        {
            img: img0,
            video: "https://www.youtube-nocookie.com/embed/o_Ay_iDRAbc"
        },
        {
            img: img1,
            video: "https://www.youtube-nocookie.com/embed/Z-zdIGxOJ4M?controls=0"
        },
        {
            img: img2,
            video: "https://www.youtube.com/embed/GNCd_ERZvZM"
        }
    ]
}