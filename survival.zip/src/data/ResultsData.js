import Img from "assets/results/ico.png";
import Img2 from "assets/results/manmini.png";

export default {
    firstText: "completed challenges",
    num: "1",
    firstHeading: "You have",
    percent: "78%",
    lastHeading: "chance for",
    rotate: "your results",
    icon: "emojione:cross-mark",
    iconText: "see more",
    img: Img,
    img2: Img2,
    rightHead: "share your results on social media",
    rightText: "Lorem ipsum dolor sit amet, consetetur diam nonumy tempor.",
    iconText1: "see results from your friends"
}